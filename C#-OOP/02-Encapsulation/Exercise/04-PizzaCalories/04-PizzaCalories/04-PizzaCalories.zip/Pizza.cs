﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;

namespace _04_PizzaCalories
{
    public class Pizza
    {
        private string _name;
        private Dough _dought;

        List<Topping> _toppings;

        public Pizza(string name)
        {
            this.Name = name;
            this._toppings = new List<Topping>();
        }

        public Dough Dough 
        { 
           private get
            {
                return this._dought;
            }
            set
            {
                if (value != null)
                {
                    this._dought = value;
                }
            }
        }

        private string Name
        {
            get
            {
                return this._name;
            }

            set
            {
                if (value == null || value == " " || value == string.Empty || value.Length > 15)
                {
                    throw new ArgumentException("Pizza name should be between 1 and 15 symbols.");
                }

                this._name = value;
            }
        }

        public void AddTopping(Topping topping)
        {
            if (this._toppings.Count >= 10)
            {
                throw new ArgumentException("Number of toppings should be in range [0..10].");
            }

            this._toppings.Add(topping);
        }

        public double TotalCalories => this.CalculateCalories();

        public override string ToString()
        {
            return $"{this.Name} - {this.TotalCalories:F2} Calories.";
        }

        private double CalculateCalories()
        {
            double result = 0;

            result += this.Dough.Calories;

            foreach (var t in this._toppings)
            {
                result += t.Calories;
            }

            return result;
        }
    }
}