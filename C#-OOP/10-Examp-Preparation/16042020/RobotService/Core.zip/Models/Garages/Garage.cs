﻿using RobotService.Models.Garages.Contracts;
using RobotService.Models.Robots.Contracts;
using System.Collections.Generic;

namespace RobotService.Models.Garages
{
    public class Garage : IGarage
    {
        private const int GarageCapacity = 10;
        private Dictionary<string, IRobot> _robots;

        public Garage()
        {
            this._robots = new Dictionary<string, IRobot>(GarageCapacity);
        }

        public IReadOnlyDictionary<string, IRobot> Robots
        {
            get
            {
                return this._robots;
            }
        }

        public void Manufacture(IRobot robot) => throw new System.NotImplementedException();
        public void Sell(string robotName, string ownerName) => throw new System.NotImplementedException();
    }
}