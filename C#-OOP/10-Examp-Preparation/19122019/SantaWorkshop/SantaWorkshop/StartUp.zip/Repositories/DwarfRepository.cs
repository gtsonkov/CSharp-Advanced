﻿using SantaWorkshop.Models.Dwarfs.Contracts;
using SantaWorkshop.Repositories.Contracts;
using System.Collections.Generic;

namespace SantaWorkshop.Repositories
{
    public class DwarfRepository : IRepository<IDwarf>
    {
        public IReadOnlyCollection<IDwarf> Models => throw new System.NotImplementedException();

        public void Add(IDwarf model) => throw new System.NotImplementedException();
        public IDwarf FindByName(string name) => throw new System.NotImplementedException();
        public bool Remove(IDwarf model) => throw new System.NotImplementedException();
    }
}