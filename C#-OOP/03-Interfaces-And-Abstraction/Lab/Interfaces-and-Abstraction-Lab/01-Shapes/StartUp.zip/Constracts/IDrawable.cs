﻿namespace Shapes.Constracts
{
    public interface IDrawable
    {
        public void Draw();
    }
}